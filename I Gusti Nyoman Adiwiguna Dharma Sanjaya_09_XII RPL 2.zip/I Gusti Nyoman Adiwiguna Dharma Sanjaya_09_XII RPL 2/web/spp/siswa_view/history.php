<?php
session_start();
require '../system/functions.php';
require '../system/Kelas.php';

?>

<?php include '../templates/header.php';



$transaksi = query("SELECT transaksi.id_transaksi, siswa.nis, transaksi.tanggal_bayar, transaksi.bulan_bayar, transaksi.tahun_bayar, petugas.nama_petugas, pembayaran.nominal , pembayaran.tahun_ajaran 
                FROM transaksi 
                INNER JOIN siswa ON transaksi.id_siswa = siswa.id_siswa 
                INNER JOIN petugas ON  transaksi.id_petugas = petugas.id_petugas
                INNER JOIN pembayaran ON transaksi.id_pembayaran = pembayaran.id_pembayaran
                WHERE transaksi.id_siswa = '$_GET[id_siswa]' ");

?>
<!-- Page Wrapper -->
<div id="wrapper">
    <!-- Content Wrapper -->
    <div id="content-wrapper" class="d-flex flex-column">

        <!-- Main Content -->
        <div id="content">

            <!-- Topbar -->
            <?php include '../templates/partials/navbar.php'; ?>
            <!-- End of Topbar -->

            <!-- Begin Page Content -->
            <div class="container-fluid">

                <!-- Page Heading -->
                <a href="index.php" class="text-secondary mb-5"><i class="fas fa-arrow-left"></i></a>
                <h1 class="h3 mb-2 text-gray-800">History</h1>
                <!-- DataTales Example -->
                <div class="card shadow mb-4">
                    <div class="card-header py-3">
                        <h6 class="m-0 font-weight-bold text-primary">History Pembayaran</h6>
                    </div>

                    <div class="card-body">
                        <div class="table">

                            <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                                <thead>
                                    <tr>
                                        <th><i class="fas fa-hashtag"></i></th>
                                        <th>NIS</th>
                                        <th>Tanggal</th>
                                        <th>Bulan Bayar</th>
                                        <th>Tahun Bayar</th>
                                        <th>Petugas</th>
                                        <th>Nominal bayar</th>
                                        <th>Tahun Ajaran</th>
                                        
                                    </tr>
                                </thead>

                                <tbody>
                                    <?php $i=1; ?>
                                    <?php foreach ($transaksi as $row) : ?>
                                        <tr>
                                            <td><?= $i ?></td>
                                            <td><?= $row['nis'] ?></td>
                                            <td><?= $row['tanggal_bayar'] ?></td>
                                            <td><?= $row['bulan_bayar'] ?></td>
                                            <td><?= $row['tahun_bayar'] ?> </td>
                                            <td><?= $row['nama_petugas'] ?></td>
                                            <td><?= $row['nominal'] ?></td>
                                            <td><?= $row['tahun_ajaran'] ?></td>
                                        </tr>
                                        <?php $i++; ?>
                                    <?php endforeach; ?>
                                    
                                </tbody>
                            </table>
                        </div>
                    </div>

                </div>

            </div>
            <!-- /.container-fluid -->

        </div>
        <!-- End of Main Content -->
    </div>
    <!-- End of Content Wrapper -->

</div>
<!-- End of Page Wrapper -->

<!-- Scroll to Top Button-->
<a class="scroll-to-top rounded" href="#page-top">
    <i class="fas fa-angle-up"></i>
</a>


<?php include '../templates/footer.php'; ?>