<?php
session_start();
require '../system/functions.php';
$siswa = mysqli_query($conn, "SELECT siswa.id_siswa, pembayaran.id_pembayaran, siswa.nisn, siswa.nis, siswa.nama, siswa.alamat, siswa.telepon, siswa.id_pembayaran, kelas.nama_kelas, kelas.kompetensi_keahlian, pengguna.username, pengguna.password,  pembayaran.tahun_ajaran, pembayaran.nominal FROM siswa INNER JOIN kelas ON siswa.id_kelas = kelas.id_kelas INNER JOIN pengguna ON siswa.id_pengguna = pengguna.id_pengguna INNER JOIN pembayaran ON siswa.id_pembayaran = pembayaran.id_pembayaran  where siswa.id_pengguna= '$_SESSION[id_pengguna]'");


?>

<?php include '../templates/header.php';




?>
<!-- Page Wrapper -->
<div id="wrapper">


    <!-- Content Wrapper -->
    <div id="content-wrapper" class="d-flex flex-column">

        <!-- Main Content -->
<div id="content">

            <!-- Topbar -->
            <?php include '../templates/partials/navbar.php'; ?>
            <!-- End of Topbar -->

            <!-- Begin Page Content -->
    <div class="container-fluid">
                <!-- Page Heading -->
        <div class="row ">
            <div class="col-8 mx-auto mb-3">
                    <div class="card">
                        <div class="card-header text-center">
                            Data Siswa
                        </div>
                        <div class="card-body">
                            <?php foreach ($siswa as $row) : ?>
                                <p>Nis : <?= $row['nis']; ?></p>
                                <p>Nama Siswa : <?= $row['nama']; ?></p>
                                <p>Kelas : <?= $row['nama_kelas']; ?></p>
                                <p>Jurusan : <?= $row['kompetensi_keahlian']; ?></p>
                                <p>Semester : <?= $row['tahun_ajaran']; ?></p>
                                <p>Nominal : <?= $row['nominal']; ?></p>
                                <a href="<?= BASEURL; ?>/siswa_view/history.php?id_siswa=<?= $row['id_siswa'] ?>" class="btn btn-secondary">History</a></td>
                            <?php endforeach; ?>
                         </div>
                         
                </div>
           
                </div>
         </div>
    </div>
            <!-- /.container-fluid -->

 </div>
        <!-- End of Main Content -->
    </div>
    <!-- End of Content Wrapper -->

</div>
<!-- End of Page Wrapper -->

<!-- Scroll to Top Button-->
<a class="scroll-to-top rounded" href="#page-top">
    <i class="fas fa-angle-up"></i>
</a>

<?php include '../templates/footer.php'; ?>