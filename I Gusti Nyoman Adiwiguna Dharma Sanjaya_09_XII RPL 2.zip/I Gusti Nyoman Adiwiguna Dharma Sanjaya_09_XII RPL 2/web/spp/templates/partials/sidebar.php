<ul class="navbar-nav bg-gradient-primary sidebar sidebar-dark accordion" id="accordionSidebar">

<!-- Sidebar - Brand -->
<a class="sidebar-brand d-flex align-items-center justify-content-center" href="#">
    <div class="sidebar-brand-icon rotate-n-15">
        <i class="fas fa-money-check"></i>
    </div>
    <div class="sidebar-brand-text mx-3">E-SPEPE</div>
</a>

<!-- Divider -->
<hr class="sidebar-divider my-0">

<!-- Nav Item - Dashboard -->
<li class="nav-item ">
    <a class="nav-link" href="<?= BASEURL;?>">
        <i class="fas fa-fw fa-home"></i>
        <span>Dashboard</span></a>
</li>

<!-- Divider -->
<hr class="sidebar-divider">

<!-- Heading -->
<div class="sidebar-heading">
    Pembayaran
</div>

<!-- Nav Item - Tables -->
<li class="nav-item">
    <a class="nav-link" href="<?= BASEURL;?>/transaksi">
        <i class="fas fa-fw fa-cash-register"></i>
        <span>Entri Pembayaran</span></a>
</li>
<!-- Divider -->
<hr class="sidebar-divider">

<!-- Heading -->
<div class="sidebar-heading">
    History
</div>
<li class="nav-item">
    <a class="nav-link" href="<?= BASEURL;?>/history">
        <i class="fas fa-fw fa-file"></i>
        <span>History Pembayaran</span></a>
</li>
<!-- Divider -->
<hr class="sidebar-divider">

<!-- Heading -->
<div class="sidebar-heading">
    Tabel
</div>

<!-- Nav Item - Pages Collapse Menu -->
<li class="nav-item">
    <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapsePages"
        aria-expanded="true" aria-controls="collapsePages">
        <i class="fas fa-fw fa-table"></i>
        <span>Tabel</span>
    </a>
    <div id="collapsePages" class="collapse" aria-labelledby="headingPages" data-parent="#accordionSidebar">
        <div class="bg-white py-2 collapse-inner rounded">
            <h6 class="collapse-header">Tabel :</h6>
        <?php if($_SESSION['role'] == 1) :?>
            <a class="collapse-item" href="<?= BASEURL;?>/siswa">Tabel siswa</a>
            <a class="collapse-item" href="<?= BASEURL;?>/pembayaran">Tabel Pembayaran</a>
            <a class="collapse-item" href="<?= BASEURL;?>/petugas">Tabel Petugas</a>
            <a class="collapse-item" href="<?= BASEURL;?>/pengguna">Tabel User</a>
            <?php endif ?>
            <a class="collapse-item" href="<?= BASEURL;?>/kelas">Tabel kelas</a>
        </div>
    </div>
</li>


<!-- Divider -->
<hr class="sidebar-divider d-none d-md-block">

<!-- Heading -->
<?php if($_SESSION['role'] == 1) :?>
<div class="sidebar-heading">
    Report
</div>
<li class="nav-item">
    <a class="nav-link" href="<?= BASEURL;?>/history/laporan.php">
        <i class="fas fa-fw fa-atlas"></i>
        <span>Generate Report</span></a>
</li>
<!-- Divider -->
<hr class="sidebar-divider d-none d-md-block">
<?php endif ?>

<!-- Sidebar Toggler (Sidebar) -->
<div class="text-center d-none d-md-inline">
    <button class="rounded-circle border-0" id="sidebarToggle"></button>
</div>
</ul>