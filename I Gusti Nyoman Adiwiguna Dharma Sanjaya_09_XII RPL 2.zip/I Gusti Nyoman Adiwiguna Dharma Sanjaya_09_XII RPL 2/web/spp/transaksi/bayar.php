<?php
session_start();
require '../system/functions.php';
include '../system/Transaksi.php';
$transaksi = new Transaksi();
$siswa = mysqli_query($conn, "SELECT siswa.id_siswa, pembayaran.id_pembayaran, siswa.nisn, siswa.nis, siswa.nama, siswa.alamat, siswa.telepon, siswa.id_pembayaran, kelas.nama_kelas, kelas.kompetensi_keahlian, pengguna.username, pengguna.password,  pembayaran.tahun_ajaran, pembayaran.nominal FROM siswa INNER JOIN kelas ON siswa.id_kelas = kelas.id_kelas INNER JOIN pengguna ON siswa.id_pengguna = pengguna.id_pengguna INNER JOIN pembayaran ON siswa.id_pembayaran = pembayaran.id_pembayaran  where id_siswa= '$_GET[id_siswa]'");
$dataBulan = mysqli_query($conn, "SELECT bulan_bayar from transaksi where id_siswa = '$_GET[id_siswa]'");

$data['data_bulan'] = [
    'januari' => ['januari', 1],
    'februari' => ['februari', 2],
    'maret' => ['maret', 3],
    'april' => ['april', 4],
    'mei' => ['mei', 5],
    'juni' => ['juni', 6],
    'juli' => ['juli', 7],
    'agustus' => ['agustus', 8],
    'september' => ['september', 9],
    'oktober' => ['oktober', 10],
    'november' => ['november', 11],
    'desember' => ['desember', 12],
];
$bulan_dibayar = [];
foreach ($dataBulan as $bulan) {
    array_push($bulan_dibayar, $bulan['bulan_bayar']);
}
$data['bulan_bayar'] = $bulan_dibayar;



if (isset($_POST['submit'])) {

    if ($transaksi->create($_POST) > 0) {
        header("Location: index.php");
        exit;
    }
}


?>


<?php include '../templates/header.php';




?>
<!-- Page Wrapper -->
<div id="wrapper">

    <!-- Sidebar -->
    <?php include '../templates/partials/sidebar.php'; ?>
    <!-- End of Sidebar -->

    <!-- Content Wrapper -->
    <div id="content-wrapper" class="d-flex flex-column">

        <!-- Main Content -->
        <div id="content">

            <!-- Topbar -->
            <?php include '../templates/partials/navbar.php'; ?>
            <!-- End of Topbar -->

            <!-- Begin Page Content -->
            <div class="container-fluid">
            <div class="row">
    <div class="col-8">
        <div class="card">
            <div class="card-header text-center">
                Data Siswa
            </div>
            <div class="card-body">
                <?php foreach ($siswa as $row) : ?>
                    <p>Nis : <?= $row['nis']; ?></p>
                    <p>Nama Siswa : <?= $row['nama']; ?></p>
                    <p>Kelas : <?= $row['nama_kelas']; ?></p>
                    <p>Jurusan : <?= $row['kompetensi_keahlian']; ?></p>
                    <p>Semester : <?= $row['tahun_ajaran']; ?></p>
                    <p>Nominal : <?= $row['nominal']; ?></p>

                <?php endforeach; ?>

            </div>
        </div>
    </div>
    <div class="col-12">
        <div class="row">
            <div class="col">
                <form method="post">
                    <?php foreach ($siswa as $row) : ?>
                        <input type="hidden" name="id_siswa" value="<?= $row['id_siswa']; ?>">
                        <input type="hidden" name="id_pembayaran" value="<?= $row['id_pembayaran']; ?>">
                    <?php endforeach; ?>

                    <div class="row">
                        <?php foreach ($data['data_bulan'] as $bulan) : ?>
                            <div class="col-4">
                                <div class="input-group mb-3">
                                    <div class="input-group-prepend">
                                        <div class="input-group-text">
                                            <input type="checkbox" name="bulan_bayar[]" value="<?= $bulan[1]; ?>" <?= in_array($bulan[1], $data['bulan_bayar']) ? "checked disabled" : ""; ?>>
                                        </div>
                                    </div>
                                    <input type="text" class="form-control" placeholder="<?= $bulan[0]; ?>" disable>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    </div>
                    <button type="submit" name="submit" class="btn btn-primary">kirim</button>
                </form>
            </div>
        </div>
    </div>
</div>


            </div>
            <!-- /.container-fluid -->

        </div>
        <!-- End of Main Content -->

        <!-- Footer -->
        <?php include '../templates/partials/footer.php'; ?>
        <!-- End of Footer -->

    </div>
    <!-- End of Content Wrapper -->

</div>
<!-- End of Page Wrapper -->

<!-- Scroll to Top Button-->
<a class="scroll-to-top rounded" href="#page-top">
    <i class="fas fa-angle-up"></i>
</a>

<?php include '../templates/footer.php'; ?>