<?php 
require '../system/functions.php';
require '../system/Siswa.php';
$id_siswa = $_GET['id_siswa'];
$siswa = new Siswa;

if($siswa->hapus($id_siswa) > 0){
    header("Location:index.php");
}else{
    echo"<script>
    alert('Data gagal dihapus');
    document.location.href = 'index.php';
</script>";
}


?>