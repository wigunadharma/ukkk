
<?php
require '../system/functions.php';
include '../system/Siswa.php';
session_start();
include '../templates/header.php';
// ngambil data siswa yang di select
$dataSiswa = query("SELECT * FROM siswa WHERE id_siswa = {$_GET['id_siswa']}")[0];
// mengambil data dari tabel kelas
$kelas = query("SELECT * FROM kelas");
// mengambil data dari tabel pembayaran
$pembayaran = query("SELECT * FROM pembayaran");
// mengambil data dari tabel pengguna
$pengguna = query("SELECT * FROM pengguna WHERE role = '3'");
if($_SESSION['role']==""){
header("Location:../login.php");
die;
}
// Tambah Data
$siswa = new Siswa();
if(isset($_POST["tambah"])){
  if($siswa->edit($_POST) >0 ) {

    header("Location:index.php");

  }else{
    echo"
    <script>
      alert('Data gagal diedit');
      document.location.href = 'index.php';
    </script>";
  }


}

?>
<!-- Page Wrapper -->
<div id="wrapper">
  <!-- Sidebar -->
  <?php include '../templates/partials/sidebar.php';?>
  <!-- End of Sidebar -->

  <!-- Content Wrapper -->
  <div id="content-wrapper" class="d-flex flex-column">
    <!-- Main Content -->
    <div id="content">
      <!-- Topbar -->
      <?php include '../templates/partials/navbar.php'?>
      
      <!-- End of Topbar -->

      <!-- Begin Page Content -->
      <div class="container-fluid">
        <!-- Page Heading -->
        <div class="d-sm-flex ualign-items-center justify-content-between mb-4">
          <h1 class="h3 mb-0 text-gray-800">Edit Data Siswa</h1>
         
        </div>

        <!-- Content Row -->
       <div class="row">
        <div class="col-12">
            <form action="" method="post">
            <div class="form-group">
                    <input type="hidden" name="id_siswa" value="<?=$dataSiswa['id_siswa'] ?>" >
                </div>
              <div class="form-group">
                <label for="namakelas">NISN</label>
                <input type="text" class ="form-control" id="namakelas" name="nisn" value="<?=$dataSiswa['nisn'] ?>">
              </div>
              <div class="form-group">
                <label for="kompetensi">NIS</label>
                <input type="text" class ="form-control" id="kompetensi" name="nis" value="<?=$dataSiswa['nis'] ?>">
              </div>
              <div class="form-group">
                <label for="kompetensi">Nama Lengkap</label>
                <input type="text" class ="form-control" id="kompetensi" name="nama"value="<?=$dataSiswa['nama'] ?>">
              </div>
              <div class="form-group">
                <label for="kompetensi">Alamat</label>
                <input type="text" class ="form-control" id="kompetensi" name="alamat" value="<?=$dataSiswa['alamat'] ?>">
              </div>
              <div class="form-group">
                <label for="kompetensi">Telepon</label>
                <input type="Number" class ="form-control" id="kompetensi" name="telepon" value="<?=$dataSiswa['telepon'] ?>">
              </div>
              <div class="form-group">                 
                <label class="my-1 mr-2" for="role">Kelas</label>
                <select class="custom-select my-1 mr-sm-2" id="role" name="id_kelas">
                   <?php foreach($kelas as $rows): ?> 
                    <option value="<?= $rows['id_kelas']?>"><?= $rows['nama_kelas']?></option>
                    <?php endforeach ?>
                </select>

                </div>
                <div class="form-group">                 
                <label class="my-1 mr-2" for="role">Pengguna</label>
                <select class="custom-select my-1 mr-sm-2" id="role" name="id_pengguna">
                   <?php foreach($pengguna as $rows): ?> 
                    <option value="<?= $rows['id_pengguna']?>"><?= $rows['username']?></option>
                    <?php endforeach ?>
                </select>
                </div>
                <div class="form-group">                 
                <label class="my-1 mr-2" for="role">Tahun Ajaran</label>
                <select class="custom-select my-1 mr-sm-2" id="role" name="id_pembayaran">
                   <?php foreach($pembayaran as $rows): ?> 
                    <option value="<?= $rows['id_pembayaran']?>"><?= $rows['tahun_ajaran']?></option>
                    <?php endforeach ?>
                </select>

                </div>
              <div class="form-group">
            <button type="submit" name="tambah" class="btn btn-success">Ubah Data</button>
              </div>

            </form>
        </div>
       </div>
      </div>
      <!-- /.container-fluid -->
    </div>
    <!-- End of Main Content -->
<!-- Footer -->
<?php include '../templates/partials/footer.php';?>
<!-- end footer -->
   
  </div>
  <!-- End of Content Wrapper -->
</div>
<!-- End of Page Wrapper -->

<!-- Scroll to Top Button-->
<a class="scroll-to-top rounded" href="#page-top">
  <i class="fas fa-angle-up"></i>
</a>




<?php include '../templates/footer.php';?>

