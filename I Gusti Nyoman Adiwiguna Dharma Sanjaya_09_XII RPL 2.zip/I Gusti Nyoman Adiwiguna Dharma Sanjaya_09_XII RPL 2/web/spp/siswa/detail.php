<?php
require '../system/functions.php';
session_start();

?>

<?php include '../templates/header.php';

$siswadetail = query("SELECT siswa.id_siswa, siswa.nisn, siswa.nis, siswa.nama, siswa.alamat, siswa.telepon, kelas.nama_kelas, kelas.kompetensi_keahlian, pengguna.username, pengguna.password,  pembayaran.tahun_ajaran, pembayaran.nominal FROM siswa INNER JOIN kelas ON siswa.id_kelas = kelas.id_kelas INNER JOIN pengguna ON siswa.id_pengguna = pengguna.id_pengguna INNER JOIN pembayaran ON siswa.id_pembayaran = pembayaran.id_pembayaran where id_siswa= {$_GET['id_siswa']}")[0];



?>
<!-- Page Wrapper -->
<div id="wrapper">

    <!-- Sidebar -->
    <?php include '../templates/partials/sidebar.php'; ?>
    <!-- End of Sidebar -->

    <!-- Content Wrapper -->
    <div id="content-wrapper" class="d-flex flex-column">

        <!-- Main Content -->
        <div id="content">

            <!-- Topbar -->
            <?php include '../templates/partials/navbar.php'; ?>
            <!-- End of Topbar -->

            <!-- Begin Page Content -->
            <div class="container-fluid">
                <a href="index.php" class="btn btn-primary mb-3">Kembali</a>
                <!-- Page Heading -->
                <h1 class="h3 mb-2 text-gray-800 mb-4">Detail Siswa</h1>
                <div class="row">
                    <div class="col-6">
                        <p>NISN : <?= $siswadetail['nisn']; ?></p>
                        <p>Nama : <?= $siswadetail['nama']; ?></p>
                        <p>Alamat : <?= $siswadetail['alamat']; ?></p>
                        <p>Kompetensi Keahlian : <?= $siswadetail['kompetensi_keahlian']; ?></p>
                    </div>
                    <div class="col-6">
                        <p> NIS: <?= $siswadetail['nis']; ?></p>
                        <p> Kelas : <?= $siswadetail['nama_kelas']; ?></p>
                        <p>Telepon : <?= $siswadetail['telepon']; ?></p>
                        <p>Tahun_ajaran : <?= $siswadetail['tahun_ajaran']; ?></p>
                    </div>
                </div>


            </div>
            <!-- /.container-fluid -->

        </div>
        <!-- End of Main Content -->

        <!-- Footer -->
        <?php include '../templates/partials/footer.php'; ?>
        <!-- End of Footer -->

    </div>
    <!-- End of Content Wrapper -->

</div>
<!-- End of Page Wrapper -->

<!-- Scroll to Top Button-->
<a class="scroll-to-top rounded" href="#page-top">
    <i class="fas fa-angle-up"></i>
</a>

<?php include '../templates/footer.php'; ?>