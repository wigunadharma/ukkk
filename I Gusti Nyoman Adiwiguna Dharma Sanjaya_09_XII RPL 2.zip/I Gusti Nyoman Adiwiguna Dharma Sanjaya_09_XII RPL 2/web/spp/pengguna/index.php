<?php
session_start();
require '../system/functions.php';

require '../templates/header.php'; 

$user = query("SELECT * FROM pengguna");

?>

    <!-- Page Wrapper -->
    <div id="wrapper">

        <!-- Sidebar -->
        <?php require '../templates/partials/sidebar.php';?>
        <!-- End of Sidebar -->

        <!-- Content Wrapper -->
        <div id="content-wrapper" class="d-flex flex-column">

            <!-- Main Content -->
            <div id="content">

                <!-- Topbar -->
               <?php require '../templates/partials/navbar.php' ?>
                <!-- End of Topbar -->

                <!-- Begin Page Content -->
                <div class="container-fluid">

                    <!-- Page Heading -->
                    <h1 class="h3 mb-2 text-gray-800">Tabel User</h1>

                    <!-- DataTales Example -->
                    <div class="card shadow mb-4">
                        <div class="card-header py-3">
                            <h6 class="m-0 font-weight-bold text-primary">Tabel User</h6>
                        </div>
                        <div class="card-body">
                            <div class="table-responsive">
                                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                                    <thead>
                                        <tr>
                                            <th><a href="tambah.php" class=" primary"><i class="fas fa-fw fa-plus"></i></a></th>
                                            <th>Username</th>
                                            <th>Password</th>
                                            <th>Role</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php foreach($user as $rows ):?>
                                        <tr>
                                            <td>
                                            <a href="<?= BASEURL;?>/pengguna/edit.php?id_pengguna=<?= $rows['id_pengguna'] ?>" class="btn btn-warning"><i class="fas fa-pen"></i></a>
                                                <a href="<?= BASEURL;?>/pengguna/hapus.php?id_pengguna=<?= $rows['id_pengguna'] ?>" class="btn btn-danger "><i class="fas fa-trash"></i></a>
                                        </td>
                                            <td><?= $rows['username'] ?></td>
                                            <td><?= $rows['password'] ?></td>
                                            <td><?= $rows['role'] ?></td>
                                           
                                        </tr>
                                        <?php endforeach; ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>

                </div>
                <!-- /.container-fluid -->

            </div>
            <!-- End of Main Content -->

            <!-- Footer -->
           <?php require '../templates/partials/footer.php'; ?>
            <!-- End of Footer -->

        </div>
        <!-- End of Content Wrapper -->

    </div>
    <!-- End of Page Wrapper -->

    <!-- Scroll to Top Button-->
    <a class="scroll-to-top rounded" href="#page-top">
        <i class="fas fa-angle-up"></i>
    </a>


  <?php require '../templates/footer.php'; ?>