<?php
require '../system/functions.php';
include '../system/Pengguna.php';
session_start();
$dataPengguna = query("SELECT * FROM pengguna WHERE id_pengguna = {$_GET['id_pengguna']}")[0];

if($_SESSION['role']==""){
    header("Location:../login.php");
    die;
}
// Tambah Data
$pengguna = new Pengguna();


if(isset($_POST["edit"])){
  if($pengguna->edit($_POST) >0 ) {

      echo"
      <script>
      alert('Data Berhasil diUbah');
      </script>";
      
    header("Location:index.php");

}else{
    echo"
    <script>
    alert('Data gagal diubah');
    document.location.href = 'index.php';
    </script>";
}


}

include '../templates/header.php';
?>
<!-- Page Wrapper -->
<div id="wrapper">
  <!-- Sidebar -->
  <?php include '../templates/partials/sidebar.php';?>
  <!-- End of Sidebar -->

  <!-- Content Wrapper -->
  <div id="content-wrapper" class="d-flex flex-column">
    <!-- Main Content -->
    <div id="content">
      <!-- Topbar -->
      <?php include '../templates/partials/navbar.php'?>
      
      <!-- End of Topbar -->

      <!-- Begin Page Content -->
      <div class="container-fluid">
        <!-- Page Heading -->
        <div class="d-sm-flex ualign-items-center justify-content-between mb-4">
          <h1 class="h3 mb-0 text-gray-800">Edit Pembayaran</h1>
         
        </div>
    
        <!-- Content Row -->
       <div class="row">
        <div class="col-12">
           
            <form action="" method="post">
                <div class="form-group">
                    <input type="hidden" name="id_pengguna" value=" <?= $dataPengguna['id_pengguna'] ?>      " >
                </div>
              <div class="form-group">
                <label for="namaPembayaran">Username</label>
                <input type="text" class ="form-control" id="namaPembayaran" name="username" value="<?= $dataPengguna ['username']?>">
              </div>
              <div class="form-group">
                <label for="nominal">Password</label>
                <input type="password" class ="form-control" id="nominal" name="password" value="<?= $dataPengguna['password']?>">
              </div>
              <div class="form-group">                 
                <label class="my-1 mr-2" for="role">Role</label>
                <select class="custom-select my-1 mr-sm-2" id="role" name="role">
                    <option selected>Choose...</option>
                    <option value="1">Admin</option>
                    <option value="2">Petugas</option>
                    <option value="3">Siswa</option>
                </select>
                
                </div>
              <div class="form-group">
            <button type="submit" name="edit" class="btn btn-success">Ubah Data</button>
              </div>
            </form>
        </div>
       </div>
      </div>
      <!-- /.container-fluid -->
    </div>
    <!-- End of Main Content -->
<!-- Footer -->
<?php include '../templates/partials/footer.php';?>
<!-- end footer -->
   
  </div>
  <!-- End of Content Wrapper -->
</div>
<!-- End of Page Wrapper -->

<!-- Scroll to Top Button-->
<a class="scroll-to-top rounded" href="#page-top">
  <i class="fas fa-angle-up"></i>
</a>




<?php include '../templates/footer.php';?>