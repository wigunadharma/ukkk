<?php 
require '../system/functions.php';
require '../system/Pengguna.php';
$id_pengguna = $_GET['id_pengguna'];
$pengguna = new Pengguna;

if($pengguna->hapus($id_pengguna) > 0){
    header("Location:index.php");
}else{
    echo"<script>
    alert('Data gagal dihapus');
    document.location.href = 'index.php';
</script>";
}


?>