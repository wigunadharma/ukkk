<?php

class Transaksi 
{
    public function create($data)
    {
        global $conn;
        $tahun = date('Y');
        $siswa = $data['id_siswa'];
        $pembayaran = $data['id_pembayaran'];
        $petugas = $_SESSION['role'];
        foreach ($data['bulan_bayar'] as $bulan) {
            $query = "INSERT INTO transaksi VALUES (null, NOW(), '$bulan', '$tahun', '$siswa', '$petugas', '$pembayaran')";
            mysqli_query($conn, $query);
        }
        return mysqli_affected_rows($conn);
    }
}

