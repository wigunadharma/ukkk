<?php 

class Pengguna
{

    // Tambah data pembayaran
    public function tambah($data)
    {
        global $conn;

        $username = htmlspecialchars($data['username']);
        $password = htmlspecialchars($data['password']);
        $role = htmlspecialchars($data['role']);
        mysqli_query($conn,"call addpengguna('$username','$password','$role')");
        return mysqli_affected_rows($conn);

    }

    // update data
    public function edit($data)
    {
        global $conn;
    
        $id = $data['id_pengguna'];
        $username = htmlspecialchars($data['username']);
        $password = htmlspecialchars($data['password']);
        $role = htmlspecialchars($data['role']);

        $query = "UPDATE pengguna SET username = '$username',
                password = '$password',
                role = '$role' 
                WHERE id_pengguna = '$id' ";
                mysqli_query($conn,$query);
                return mysqli_affected_rows($conn);

    }


    // Hapus Data
    public function hapus($id_pengguna)
    {
        global $conn;
        mysqli_query($conn,"DELETE  FROM pengguna WHERE id_pengguna = '$id_pengguna'");
        return mysqli_affected_rows($conn);

    }
}