<?php 

class Petugas{

    // Tambah data 
    public function tambah($data)
    {
        global $conn;

        $nama_petugas = htmlspecialchars($data['nama_petugas']);
        $id_pengguna = htmlspecialchars($data['id_pengguna']);
        mysqli_query($conn,"call addpetugas('$nama_petugas','$id_pengguna')");
        return mysqli_affected_rows($conn);

    }

    // update data
    public function edit($data)
    {
        global $conn;
    
        $id = $data['id_petugas'];
        $nama_petugas = htmlspecialchars($data['nama_petugas']);
        $id_pengguna = htmlspecialchars($data['id_pengguna']);

        $query = "UPDATE petugas SET nama_petugas = '$nama_petugas',
                id_pengguna = '$id_pengguna'
                WHERE id_petugas = '$id' ";
                mysqli_query($conn,$query);
                return mysqli_affected_rows($conn);

    }


    // Hapus Data
    public function hapus($id_petugas)
    {
        global $conn;
        mysqli_query($conn,"DELETE  FROM petugas WHERE id_petugas = '$id_petugas'");
        return mysqli_affected_rows($conn);

    }
}