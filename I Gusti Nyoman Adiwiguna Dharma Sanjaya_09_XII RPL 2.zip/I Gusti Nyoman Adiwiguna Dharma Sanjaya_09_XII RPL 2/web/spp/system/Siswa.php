<?php 

class Siswa
{

    // Tambah data pembayaran
    public function tambah($data)
    {
        global $conn;

        $nisn = htmlspecialchars($data['nisn']);
        $nis = htmlspecialchars($data['nis']);
        $nama = htmlspecialchars($data['nama']);
        $alamat = htmlspecialchars($data['alamat']);
        $telepon = htmlspecialchars($data['telepon']);
        $id_kelas = htmlspecialchars($data['id_kelas']);
        $id_pengguna = htmlspecialchars($data['id_pengguna']);
        $id_pembayaran = htmlspecialchars($data['id_pembayaran']);
        $query = " INSERT INTO siswa VALUES(NULL,'$nisn','$nis','$nama','$alamat','$telepon','$id_kelas','$id_pengguna','$id_pembayaran')";
        mysqli_query($conn,$query);
        return mysqli_affected_rows($conn);

    }

    // update data
    public function edit($data)
    {
        global $conn;
    
        $id = $data['id_siswa'];
        $nisn = htmlspecialchars($data['nisn']);
        $nis = htmlspecialchars($data['nis']);
        $nama = htmlspecialchars($data['nama']);
        $alamat = htmlspecialchars($data['alamat']);
        $telepon = htmlspecialchars($data['telepon']);
        $id_kelas = htmlspecialchars($data['id_kelas']);
        $id_pengguna = htmlspecialchars($data['id_pengguna']);
        $id_pembayaran = htmlspecialchars($data['id_pembayaran']);

        $query = "UPDATE siswa SET nisn = '$nisn',
                nis = '$nis',
                nama = '$nama',
                alamat = '$alamat',
                telepon = '$telepon',
                id_kelas = '$id_kelas',
                id_pengguna = '$id_pengguna',
                id_pembayaran = '$id_pembayaran' 
                WHERE id_siswa = '$id' ";
                mysqli_query($conn,$query);
                return mysqli_affected_rows($conn);

    }


    // Hapus Data
    public function hapus($id_siswa)
    {
        global $conn;
        mysqli_query($conn,"DELETE  FROM siswa WHERE id_siswa = '$id_siswa'");
        return mysqli_affected_rows($conn);

    }
}