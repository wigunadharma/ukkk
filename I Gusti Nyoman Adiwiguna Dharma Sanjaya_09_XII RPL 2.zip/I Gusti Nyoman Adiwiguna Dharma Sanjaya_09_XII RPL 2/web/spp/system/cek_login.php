<?php
session_start();


// Menghubungkan dengan functions
require 'functions.php';

// Menangkap data yang dikkirim dari form login
$username = $_POST['username'];
$password = $_POST['password'];
// Query login
$result = mysqli_query($conn, "SELECT * FROM pengguna where username = '$username' and password = '$password'");
$cek = mysqli_num_rows($result);

// cek role multi user
if ($cek > 0) {  
    $data = mysqli_fetch_assoc($result);
    $_SESSION['user'] = [
        'id_pengguna'=> $data['id_pengguna'],
        'username' => $data['username'],
        'password' => $data['password'],
        'role' => $data['role']
    ]; 

    if ($data['role'] == "1") {
        $_SESSION['username'] = $username;
        $_SESSION['id_petugas'] = $data['id_petugas'];
        $_SESSION['role'] = "1";
        header("Location: ../index.php");
    } elseif ($data['role'] == "2") {
        $_SESSION['username'] = $username;
        $_SESSION['role'] = "2";
        header("Location: ../index.php");
    } elseif ($data['role'] == "3") {
        $_SESSION['id_pengguna'] = $data['id_pengguna'];
        $_SESSION['id_siswa'] = $data['id_siswa'];
        $_SESSION['username'] = $username;
        $_SESSION['role'] = "3";
        header("Location: ../siswa_view/index.php");
    } else {
        header("Location:../login.php?pesan=salah");
    }
} else {

    header("Location:../login.php?pesan=salah");
}