<?php 
// koneksi database
$conn = mysqli_connect('localhost','root','','spp');
// pembuatan base url
define('BASEURL','http://localhost/spp');

function query($query)
{
    global $conn;
    $result = mysqli_query($conn,$query);
    $rows = [];
    while($row = mysqli_fetch_assoc($result)){
        $rows[] = $row;
    }
    return $rows;
}


?>