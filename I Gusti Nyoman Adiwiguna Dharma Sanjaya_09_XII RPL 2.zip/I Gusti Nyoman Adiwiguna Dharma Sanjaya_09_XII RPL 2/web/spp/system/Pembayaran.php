<?php 

class Pembayaran
{

    // Tambah data pembayaran
    public function tambah($data)
    {
        global $conn;

        $tahun = htmlspecialchars($data['tahun_ajaran']);
        $nominal = htmlspecialchars($data['nominal']);
        mysqli_query($conn,"call addPembayaran('$tahun','$nominal')");
        return mysqli_affected_rows($conn);

    }

    // update data
    public function edit($data)
    {
        global $conn;
    
        $id = $data['id_pembayaran'];
        $tahun = htmlspecialchars($data['tahun_ajaran']);
        $nominal = htmlspecialchars($data['nominal']);

        $query = "UPDATE pembayaran SET tahun_ajaran = '$tahun',
                nominal = '$nominal' 
                WHERE id_pembayaran = '$id' ";
                mysqli_query($conn,$query);
                return mysqli_affected_rows($conn);

    }


    // Hapus Data
    public function hapus($id_pembayaran)
    {
        global $conn;
        mysqli_query($conn,"DELETE  FROM pembayaran WHERE id_pembayaran = '$id_pembayaran'");
        return mysqli_affected_rows($conn);

    }
}