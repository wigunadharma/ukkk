<?php 
require '../system/functions.php';
require '../system/Petugas.php';
$id_petugas = $_GET['id_petugas'];
$petugas = new Petugas;

if($petugas->hapus($id_petugas) > 0){
    header("Location:index.php");
}else{
    echo"<script>
    alert('Data gagal dihapus');
    document.location.href = 'index.php';
</script>";
}


?>
