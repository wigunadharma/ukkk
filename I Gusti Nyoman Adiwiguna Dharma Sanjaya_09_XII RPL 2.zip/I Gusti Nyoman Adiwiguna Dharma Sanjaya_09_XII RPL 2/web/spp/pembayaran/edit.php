<?php
require '../system/functions.php';
include '../system/Pembayaran.php';
session_start();
$dataPembayaran = query("SELECT * FROM pembayaran WHERE id_pembayaran = {$_GET['id_pembayaran']}")[0];

if($_SESSION['role']==""){
    header("Location:../login.php");
    die;
}
// Tambah Data
$pembayaran = new Pembayaran();


if(isset($_POST["edit"])){
  if($pembayaran->edit($_POST) >0 ) {

      echo"
      <script>
      alert('Data Berhasil diUbah');
      </script>";
      
    header("Location:index.php");

}else{
    echo"
    <script>
    alert('Data gagal diubah');
    document.location.href = 'index.php';
    </script>";
}


}

include '../templates/header.php';
?>
<!-- Page Wrapper -->
<div id="wrapper">
  <!-- Sidebar -->
  <?php include '../templates/partials/sidebar.php';?>
  <!-- End of Sidebar -->

  <!-- Content Wrapper -->
  <div id="content-wrapper" class="d-flex flex-column">
    <!-- Main Content -->
    <div id="content">
      <!-- Topbar -->
      <?php include '../templates/partials/navbar.php'?>
      
      <!-- End of Topbar -->

      <!-- Begin Page Content -->
      <div class="container-fluid">
        <!-- Page Heading -->
        <div class="d-sm-flex ualign-items-center justify-content-between mb-4">
          <h1 class="h3 mb-0 text-gray-800">Edit Pembayaran</h1>
         
        </div>
    
        <!-- Content Row -->
       <div class="row">
        <div class="col-12">
           
            <form action="" method="post">
                <div class="form-group">
                    <input type="hidden" name="id_pembayaran" value=" <?= $dataPembayaran['id_pembayaran'] ?>      " >
                </div>
              <div class="form-group">
                <label for="namaPembayaran">Tahun Ajaran</label>
                <input type="text" class ="form-control" id="namaPembayaran" name="tahun_ajaran" value="<?= $dataPembayaran ['tahun_ajaran']?>">
              </div>
              <div class="form-group">
                <label for="nominal">Nominal</label>
                <input type="text" class ="form-control" id="nominal" name="nominal" value="<?= $dataPembayaran['nominal']?>">
              </div>
              <div class="form-group">
            <button type="submit" name="edit" class="btn btn-success">Ubah Data</button>
              </div>
            </form>
        </div>
       </div>
      </div>
      <!-- /.container-fluid -->
    </div>
    <!-- End of Main Content -->
<!-- Footer -->
<?php include '../templates/partials/footer.php';?>
<!-- end footer -->
   
  </div>
  <!-- End of Content Wrapper -->
</div>
<!-- End of Page Wrapper -->

<!-- Scroll to Top Button-->
<a class="scroll-to-top rounded" href="#page-top">
  <i class="fas fa-angle-up"></i>
</a>




<?php include '../templates/footer.php';?>