<?php 
require '../system/functions.php';
require '../system/Pembayaran.php';
$id_pembayaran = $_GET['id_pembayaran'];
$pembayaran = new Pembayaran;

if($pembayaran->hapus($id_pembayaran) > 0){
    header("Location:index.php");
}else{
    echo"<script>
    alert('Data gagal dihapus');
    document.location.href = 'index.php';
</script>";
}


?>